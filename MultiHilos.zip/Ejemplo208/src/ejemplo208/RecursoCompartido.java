/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplo208;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
UNIVERSIDAD AUTONOMA DEL ESTADO DE MEXICO
CENTRO UNIVERSITARIO UAEM ZUMPANGO
INGENIERIA EN COMPUTACION
PROGRAMACION AVANZADA 2018-B

DESCRIPCION: 

ARCHIVO: RecursoCompartido.java

FECHA: 3/nov/2018
ALUMNOS(S):Romero Palmas Ana Lilia
PROFESOR: ASDRUBAL LOPEZ CHAU
*/
/**
 *
 * @author ICO CU ZUMPANGO
 */
public class RecursoCompartido {
    private int i=1;
    private boolean flagWinner = false; //True  = someone has arrived
    private String nameWinner = "";
    JTable jTable1;
    
    public RecursoCompartido(JTable jTable1){
        this.jTable1 = jTable1;
    }
    
    public synchronized boolean isFlagWinner() {
        return flagWinner;
    }

    public synchronized void setFlagWinner(boolean flagWinner) {
        this.flagWinner = flagWinner;
    }

    public String getNameWinner() {
        return nameWinner;
    }

    public synchronized int getCorredores(){
        return i;
    }
    
    public synchronized void setCorredores(int i){
        this.i = i;
    }
    
    public synchronized void setNameWinner(String nameWinner) {
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
        if (!isFlagWinner()) {
            this.nameWinner = nameWinner;
            flagWinner = true;
            //System.out.println("El ganador es: " + nameWinner);
            modelo.addRow(new Object[]{i,nameWinner});//envia los datos del label ganador a la tabla 
        }else{
            i++;
           // System.out.println("Soy "+ nameWinner + ", ya gano otro "+ this.nameWinner);
            modelo.addRow(new Object[]{i,nameWinner});//envia los datos de los labels conforme van llegando despues del ganador a la tabla
        }
        
    }
}