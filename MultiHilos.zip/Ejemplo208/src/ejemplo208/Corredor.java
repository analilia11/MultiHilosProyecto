/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplo208;

import java.util.Random;
import javax.swing.JLabel;
/*
UNIVERSIDAD AUTONOMA DEL ESTADO DE MEXICO
CENTRO UNIVERSITARIO UAEM ZUMPANGO
INGENIERIA EN COMPUTACION
PROGRAMACION AVANZADA 2018-B

DESCRIPCION: 

ARCHIVO: Corredor.java
FECHA: 3/nov/2018
ALUMNOS(S):Romero Palmas Ana Lilia
PROFESOR: ASDRUBAL LOPEZ CHAU
*/
public class Corredor implements Runnable {
    private int ancho = 0;
    JLabel label,label2;
    
    private RecursoCompartido recursoCompartido;
    
    @Override
    public void run() {//Clase derivada de thread 
        //En el metodo run se genera la accion del subproceso 
        Random r = new Random(System.nanoTime());// generar tiempo de forma aleatoria 
        int avance = 0,flag=0;
        while (avance < ancho ) {
            //if (recursoCompartido.isFlagWinner()) {
               // break;
            if (r.nextInt(100) < 50 ) {
                avance ++;
            } else {
                avance += 0;
            }
            if(label.getX()<ancho/2-20){
                label.setLocation(avance, label.getY());
            }
            else{
                if(flag==0){
                    avance+=45;
                    flag=1;
                    label2.setLocation(avance, label.getY());
                }
                else
                    label2.setLocation(avance, label.getY());
            }
            try {
                Thread.sleep(10 + r.nextInt(10));//tiempo avance
            } catch (InterruptedException ex) {
            }
        }
        recursoCompartido.setNameWinner(label.getText());
        //label.setLocation(10, 20);
    }

    public Corredor(JLabel label, JLabel label2) {
        this.label = label;
        this.label2 = label2;
    }
    
    public Corredor(JLabel label, JLabel label2, RecursoCompartido recursoCompartido,int ancho) {
        this(label,label2);
        this.ancho =  ancho ;
        this.recursoCompartido = recursoCompartido;
    }
    
    public RecursoCompartido getRecursoCompartido() {
        return recursoCompartido;
    }

    public void setRecursoCompartido(RecursoCompartido recursoCompartido) {
        this.recursoCompartido = recursoCompartido;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }
    
}
